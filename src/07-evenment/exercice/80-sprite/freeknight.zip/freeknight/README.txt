Animation created with DragonBones.A completely free skeletal animation editor software.
Just in case you want to create or modify the animations, DragonBones source files and character body parts are included.

Download the software here: http://dragonbones.github.io/